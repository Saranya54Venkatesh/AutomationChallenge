package StepDefinitions;

//import Base.TestBase;
import Base.TestBase;
import Pages.TestPage;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.IOException;
public class TestPageStepDefs extends TestBase {


        Scenario scenario;
        TestPage testPage;
        String oAuthClientName;
        String backendClientName;


        public TestPageStepDefs() throws IOException {
            super();


        }

        @Before()
        public void fetchScenarioName(Scenario sc) throws IOException {
            this.scenario=sc;
            System.out.println("Scenario Name::"+sc.getName());
            browserIntialization();
        }

        @After(order=1)
        public void screenshots() {
            TakesScreenshot scrn= (TakesScreenshot) driver;
            byte[] screenshot=scrn.getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshot, "image/png", "SCREENSHOT");
        }
//
//        @After(order=1)
//        public void closeBrowser() {
//            driver.quit();
//        }

        @Given("user launches URL")
        public void launch_authserver_url() throws InterruptedException {
            launchUrl();
            testPage =new TestPage(driver);
            testPage.verifyTestPage();
        }

        @When("Sign In page is displayed")
        public void signInPageIsDisplayed() {
           testPage.verifySignIn();
        }


        @Then("Enter the Email and Password")
        public void enterTheEmailAndPassword() {
            testPage.enterEmailAndPasswordInputs(prop.getProperty("email"),prop.getProperty("password") );
        }

        @And("Click on SignIn")
        public void clickOnSignIn() {
            testPage.clickOnSign();
        }


    @Then("verify if the second list item is {string}")
    public void verifyIfTheSecondListItemIs(String arg0) {
        testPage.verifySecondItems(arg0);
    }

    @And("verify the second list item's badge value is {string}")
    public void verifyTheSecondListItemSBadgeValueIs(String arg0) {
        testPage.verifySecondItemBadgevalue(arg0);
    }

    @When("verify if the list contails {int} list items")
    public void verifyIfTheListContailsListItems(int arg0) {
        testPage.verifyListItems(arg0);
    }

    @When("verify if the {string} is the default selected value")
    public void verifyIfTheIsTheDefaultSelectedValue(String arg0) {
         testPage.verifyDefaultSelectOption(arg0);
    }

    @Then("Select {string} from the select list")
    public void selectFromTheSelectList(String arg0) throws InterruptedException {
            testPage.selectOption3(arg0);
    }

    @And("verify {string} is selected from the select list")
    public void verifyIsSelectedFromTheSelectList(String arg0) {
            testPage.verifyOptionIsSelected(arg0);
    }

    @Then("verify if the {string} is enabled")
    public void verifyIfTheIsEnabled(String arg0) {
            testPage.verifyButtonIsEnabledOrDisabled(arg0);
    }

    @And("verify if {string} is disabled")
    public void verifyIfIsDisabled(String arg0) {
        testPage.verifyButtonIsEnabledOrDisabled(arg0);
    }

    @When("Button is displayed")
    public void buttonIsDisplayed() {
            testPage.waitTillButtonIsLoaded();
    }

    @Then("Click on the button")
    public void clickOnTheButton() {
            testPage.clickTest5Button();
    }

    @And("Verify the success message")
    public void verifyTheSuccessMessage() {
        testPage.verifySuccessMessage();
    }

    @Then("verify the value of the cell at coordinates {int}, {int} is {string}")
    public void verifyTheValueOfTheCellAtCoordinatesIs(int arg0, int arg1, String arg2) {
            testPage.verifyCellvalue(arg0,arg1,arg2);
    }
}

