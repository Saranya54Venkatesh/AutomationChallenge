package Pages;


import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.*;

public class TestPage {
    WebDriver driver;
    WebDriverWait wait;
    Actions action;
    Select s;
    Robot robot;

    @FindBy(id = "inputEmail")
    WebElement inputEmail;

    @FindBy(xpath = "//a[text()='Test Page']")
    WebElement testPage;

    @FindBy(id="inputPassword")
    WebElement inputPassword;

    @FindBy(xpath = "//button[@type=\"submit\"]")
    WebElement signInButton;

    @FindBy(xpath = "//*[@id=\"test-2-div\"]/ul")
    WebElement listGroup;


    @FindBy(id="dropdownMenuButton")
    WebElement dropdownMenuButton;
    @FindBy(xpath = "//div[@id=\"test-4-div\"]/button[1]")
    WebElement button1;
    @FindBy(xpath = "//div[@id=\"test-4-div\"]/button[2]")
    WebElement button2;

    @FindBy(id="test5-button")
    WebElement test5Button;

    @FindBy(id="test5-alert")
    WebElement successMsg;

    String[] parts;

    List<WebElement> listItems;
    public TestPage(WebDriver driver) {
        this.driver=driver;
        wait=new WebDriverWait(driver, Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
    }

    public void verifyTestPage(){
        try
        {
            assertTrue(testPage.isDisplayed(),"Test Page is not displayed");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void verifySignIn(){
        assertTrue(inputEmail.isDisplayed(),"Email text box is not displayed");
        assertTrue(inputPassword.isDisplayed(),"Password text box is not displayed");
        assertTrue(signInButton.isDisplayed(),"Sign In button is not displayed");
    }

    public void enterEmailAndPasswordInputs(String email, String password){
        inputEmail.sendKeys(email);
        inputPassword.sendKeys(password);
    }

    public void clickOnSign(){
        clickButton(signInButton);
    }

    public void verifyListItems(int explistItemCount){
        listItems=new ArrayList<>();
        listItems= listGroup.findElements(By.tagName("li"));
        int actualListItemCounts=listItems.size();
        assertEquals(explistItemCount,actualListItemCounts);
    }

    public  void verifySecondItems(String expSecondItem){
        String secondItem=listItems.get(1).getText();
        parts = secondItem.split("\\s+(?=\\d+$)");
        String actualSecondItem=parts[0];
        assertEquals(actualSecondItem,expSecondItem);
    }

    public void verifySecondItemBadgevalue(String expBadgeValue){
        String actualBadgevalue=parts[1];
        assertEquals(actualBadgevalue,expBadgeValue);
    }

    public void verifyDefaultSelectOption(String expectedVSelectValue){
       String actualSelectedValue= dropdownMenuButton.getText();
       assertEquals(actualSelectedValue,expectedVSelectValue);
    }

    public  void selectOption3(String option) throws InterruptedException {
        clickButton(dropdownMenuButton);
        WebElement dropDown= driver.findElement(By.xpath("//a[@class=\"dropdown-item\" and text()=\""+option+"\"]"));
        clickButton(dropDown);

    }

    public void verifyOptionIsSelected(String expOption){
        String actualOption= dropdownMenuButton.getText();
        assertEquals(actualOption,expOption);
    }

    public void verifyButtonIsEnabledOrDisabled(String button){
        if(button.contains("1")){
        assertTrue(button1.isEnabled(),button+" is not enabled");}
        else{
            assertFalse(button2.isEnabled(),button+" is not disabled");
        }
    }

    public void waitTillButtonIsLoaded(){
        wait.until(ExpectedConditions.visibilityOf(test5Button));
    }

    public void clickTest5Button(){
        clickButton(test5Button);
    }

    public void clickButton(WebElement element){
        element.click();
    }

    public void verifySuccessMessage(){
        assertEquals(successMsg.getText(),"You clicked a button!");
    }

    public WebElement findTheCellValue(int cord1, int cord2){
        WebElement cellValue= driver.findElement(By.xpath("//table/tbody/tr["+(cord1+1)+"]/td["+(cord2+1)+"]"));
        return cellValue;
    }

    public void verifyCellvalue(int cord1, int cord2, String expvalue){
        String actvalue= findTheCellValue(cord1,cord2).getText();
        assertEquals(actvalue,expvalue);
    }














}
