package Base;

import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase{

    public static Properties prop;

    public static WebDriver driver = null;
    protected static WebDriverWait wait;
    protected static String var = System.getProperty("user.dir");

    public TestBase() throws IOException {
        init();
    }


    public static void init(){
        LoadProperties init = LoadProperties.getInstance();
        prop = init.loadPropertiesFile();
    }


    public static void browserIntialization() {
        if(prop.get("browser").equals("chrome")){
            ChromeOptions co = new ChromeOptions();
            HashMap<String, Object> chromePref= new HashMap<String, Object>();
            chromePref.put("download.default_directory","user.home"+"\\Downloads\\");
            chromePref.put("download.prompt_for_download", true);
            co.addArguments("--disable-notifications");
            co.setExperimentalOption("prefs", chromePref);
            driver= WebDriverManager.chromedriver().capabilities(co).create();
        }

        else if (prop.get("browser").equals("firefox")) {
            driver=WebDriverManager.firefoxdriver().create();
        }

    }



    public static void launchUrl() {
        driver.get(prop.getProperty("url"));
        driver.manage().window().maximize();
        wait= new WebDriverWait(driver,Duration.ofSeconds(30));
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(15));
    }


}
