package Base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class LoadProperties {

    private String var = System.getProperty("user.dir");
    private Properties prop;

    private static LoadProperties loadProperties = new LoadProperties();

    private LoadProperties() {}

    public Properties loadPropertiesFile(){
        prop = new Properties();
        try {
            FileInputStream file = new FileInputStream(var+"/src/test/resources/Config.properties");
            prop.load(file);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            e.getCause();
            e.getMessage();
        }
        return prop;
    }

    public static LoadProperties getInstance(){
        return loadProperties;
    }

}
